

SONDERZEICHEN = "[@_!#$%^&*()<>?/\|}{~:]"