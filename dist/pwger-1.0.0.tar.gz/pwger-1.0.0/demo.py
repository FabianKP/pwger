
from pwger import pwger

print(pwger())

print(pwger(n=8))

print(pwger(g=True))

print(pwger(z=True))

print(pwger(s=True))

print(pwger(n=3, g=True))

print(pwger(z=True, s=True))